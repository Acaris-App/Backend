const db = require('../config/db');

exports.createOTPTx = async (client, userId, code, type, expiresAt) => {
  await client.query(
    `INSERT INTO otp_codes (user_id, code, type, expires_at)
     VALUES ($1, $2, $3, $4)`,
    [userId, code, type, expiresAt]
  );
};

exports.findOTPByUser = async (userId, type) => {
  const result = await db.query(
    `SELECT * FROM otp_codes 
     WHERE user_id = $1 
     AND type = $2 
     AND is_used = false 
     AND expires_at > NOW()
     ORDER BY created_at DESC
     LIMIT 1`,
    [userId, type]
  );

  return result.rows[0];
};

exports.markAsUsed = async (id) => {
  await db.query(
    'UPDATE otp_codes SET is_used = TRUE WHERE id = $1',
    [id]
  );
};