const Joi = require('joi');

// 🎓 MAHASISWA
const mahasiswaSchema = Joi.object({
  name: Joi.string().min(3).required(),
  email: Joi.string().email().required(),
  password: Joi.string().min(6).required(),
  role: Joi.string().valid('mahasiswa').required(),
  npm_nip: Joi.string().required(),
  angkatan: Joi.number().min(2000).required(),
  kode_kelas: Joi.string().required() // 🔥 WAJIB
});

// 👨‍🏫 DOSEN
const dosenSchema = Joi.object({
  name: Joi.string().required(),
  email: Joi.string().email().required(),
  password: Joi.string().min(6).required(),
  role: Joi.string().valid('dosen').required(),
  npm_nip: Joi.string().required()
});

// 👨‍💼 ADMIN
const adminSchema = Joi.object({
  name: Joi.string().required(),
  email: Joi.string().email().required(),
  password: Joi.string().min(6).required(),
  role: Joi.string().valid('admin').required(),
  npm_nip: Joi.string().required()
});

exports.validateRegister = (data) => {

  if (data.role === 'mahasiswa') {
    return mahasiswaSchema.validate(data);
  }

  if (data.role === 'dosen') {
    return dosenSchema.validate(data);
  }

  if (data.role === 'admin') {
    return adminSchema.validate(data);
  }

  return { error: { message: "Role tidak valid" } };
};