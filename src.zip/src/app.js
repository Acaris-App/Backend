require('dotenv').config();
const express = require('express');
const app = express();

const authRoutes = require('./routes/auth.routes');
const { errorHandler } = require('./middlewares/error.middleware');

app.use(express.json());

// Routes
app.use('/auth', authRoutes);

// Error Handler
app.use(errorHandler);

app.listen(process.env.PORT, () => {
  console.log(`Server running on port ${process.env.PORT}`);
});